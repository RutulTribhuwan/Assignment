package com.example.TaskStockMarket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.TaskStockMarket.model.Stock;
import com.example.TaskStockMarket.service.StockService;

@RestController
@RequestMapping("/api/v1/stocks")
public class StockController {

	
	@Autowired
	private StockService stockService;
	
	
	
	
	
	
	 @PostMapping
	    public Stock createStock(@RequestBody Stock stock) {
	        return stockService.saveStock(stock);
	    }

	    @GetMapping
	    public List<Stock> getAllStocks() {
	        return stockService.getAllStocks();
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Stock> getStockById(@PathVariable Long id) {
	        return stockService.getStockById(id)
	                .map(ResponseEntity::ok)
	                .orElse(ResponseEntity.notFound().build());
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Stock> updateStock(@PathVariable Long id, @RequestBody Stock stockDetails) {
	        return stockService.getStockById(id)
	               .map(stock ->{
	            	 stock.setStockname(stockDetails.getStockname());
	            	 stock.setPricedate(stockDetails.getPricedate());
	            	 stock.setPrice(stockDetails.getPrice());
	            	 stock.setQuantity(stockDetails.getQuantity());
	            	 stock.setVolume(stock.getVolume());
	            	 Stock updatedStock=stockService.saveStock(stockDetails);
	            	 return ResponseEntity.ok(updatedStock);
	               })
	               .orElse(ResponseEntity.notFound().build());
	    }   
	        
	        @DeleteMapping("/{id}")
	        public ResponseEntity<Object> deleteStock(@PathVariable Long id) {
	            return stockService.getStockById(id)
	                    .map(stock -> {
	                        stockService.deleteStock(id);
	                        return ResponseEntity.noContent().build();
	                    })
	                    .orElse(ResponseEntity.notFound().build());
	        }
	        
	        @GetMapping("/search")
	        public List<Stock> searchStocks(@RequestParam(required = false) String stockName) {
	            return stockService.searchStocks(stockName);
	        }
	        
	        
	        
	        
	        
	        
	        
}

	
	
	
	
	

