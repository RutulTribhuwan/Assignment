package com.example.TaskStockMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskStockMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
